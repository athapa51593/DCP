import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect,
  Switch,
  withRouter,
  browserHistory,
} from "react-router-dom";
import { createBrowserHistory } from "history";
import UploadFile from "../containers/uploadFileContainer/uploadFileContainer";
import DocumentList from "../containers/documentListContainer/documentListContainer";

import Login from "../containers/loginpage/Login";

export const history = createBrowserHistory();

export default class Routes extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Router history={history}>
        <div>
          <Link to="/"></Link>

          <Route
            exact
            path="/uploadFile"
            render={(props) => {
              return <UploadFile {...props} />;
            }}
          ></Route>

          <Route
            exact
            path="/documentList"
            render={(props) => {
              return <DocumentList {...props} />;
            }}
          ></Route>
          
          <Route exact path="/login"
           render={(props) => {
            return <Login style={{backgroundColor: 'blue'}} {...props} />;
          }}
          >
            
          </Route>

        </div>
      </Router>
    );
  }
}
