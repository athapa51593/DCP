import React, { Component } from "react";
import RefreshImg from "../../assets/images/refreshImg.png";
import './style.css';
import PopUp from "../popUp/PopUp";

class DocumentList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isToggleOn: false,
      isTogglePopup: false
    };

    this.handleClick = this.handleClick.bind(this);
    this.togglePop = this.togglePop.bind(this);
  }

  togglePop = () => {
    this.setState((state) => ({
      isTogglePopup: !state.isTogglePopup
    }));
  };

  handleClick() {
    this.setState(state => ({
      isToggleOn: !state.isToggleOn
    }));
  }

  render() {
    return (
      <React.Fragment>
        <div className="bg">
        {this.state.isTogglePopup ? <PopUp toggle={this.togglePop} /> : null}
          <div className="container-fluid">
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div className="upload-title" style={{ paddingLeft: "15px" }}>Document Lists</div>
              <div style={{ display: "flex" }}>
                <div className="moodys-title">MOODY'S</div>
              </div>
            </div>
            <div style={{ display: "flex" }}>
              <div className="up-title col-md-3" style={{ fontSize: "30px", paddingLeft: "15px" }} >Business Element Name</div>
              <div style={{ marginLeft: "auto" }}>
                <nav className="navbar" style={{ margin: "15px 0" }}>
                  <div className="container-fluid" style={{ marginLeft: "auto", display: "flex" }}>
                    <div className="navbar-header">
                      <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span className="sr-only">Toggle navigation</span>
                        <span className="icon-bar"></span>
                        <span className="icon-bar"></span>
                        <span className="icon-bar"></span>
                      </button>

                    </div>


                    <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                      {/* <form className="navbar-form navbar-right navbar-form-search" role="search">
                        <div className="search-form-container hdn" id="search-input-container">
                          <div className="search-input-group">
                            <button type="button" className="btn btn-default" id="hide-search-input-container"><span className="glyphicon glyphicon-option-horizontal" aria-hidden="true"></span></button>
                            <div className="form-group">
                              <input type="text" className="form-control" placeholder="Search for..." />
                            </div>
                          </div>

                        </div>

                      </form> */}
                      <ul className="nav navbar-nav navbar-right navbar-nav-primary">
                        <li><a href="#">New</a></li>
                        <li><a href="#">Save</a></li>
                        <li><a href="#">Open</a></li>
                        <li><a href="#">Share</a></li>
                        <li><a href="#"><i style={{ color: "#000" }} className="fa fa-refresh"></i>&nbsp; Auto-refresh</a></li>
                      </ul>
                    </div>
                  </div>
                </nav>
              </div>
            </div>

          </div>





          <div className="container-fluid">
            <div className="col-md-12">
              <div className="row">
                <div className="col-md-12">
                  <input style={{ width: "calc(100% - 50px)", height: "40px" }} type="text" placeholder="Search....." aria-label="Search" />
                  <button style={{ width: "50px", height: "40px" }} type="submit"><i className="fa fa-search"></i></button>
                </div>
              </div>
            </div>
          </div>

          <br />
          <br />
          <br />
          <br />
          <br />
          <div className="container-fluid">
            <div className="col-md-8">
            </div>
            <div className="col-md-4 filter-title filter-dropdown" >Add a filter  <span class="glyphicon glyphicon-plus" onClick={this.togglePop}></span>
            </div>
          </div>


          <br />
          <div className="container-fluid" style={{ paddingBottom: "70px" }}>
            <div className="col-md-8">
              <div className="panel panel-default" style={{ height: "400px", }}>
                <div className="panel-heading" style={{ backgroundColor: "#fff", fontSize: "20px" }}><b>_source</b></div>
                <div className="panel-body" >
                  <div>
                    <span style={{ cursor: "pointer" }} onClick={this.handleClick}>
                    {this.state.isToggleOn ? <i class="glyphicon glyphicon-triangle-bottom"></i> : <i class="glyphicon glyphicon-triangle-right"></i> }
                    
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="panel panel-default" style={{ height: "400px", }}>
                <div className="panel-body" >
                  <div className="row">
                    <div className="col-md-12">
                      <h4><b>Selected Fields</b></h4>
                    </div>
                  </div>
                  <br />
                  <br />
                  <br />
                  <div className="row">
                    <div className="col-md-10">
                      <br />
                      <h4><b>Available Fields</b></h4>
                    </div>
                    <div className="col-md-2">
                      <h3><span className="glyphicon glyphicon-cog"></span></h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        
      </React.Fragment>
    )
  }

}
export default DocumentList;