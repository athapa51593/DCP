import React, { Component } from "react";
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import UploadFileContainer from "../../containers/uploadFileContainer/uploadFileContainer";
import Dropzone from "./dropZone";
import './style.css';

class UplaodFile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            companyName: '',
            bvdid: '',
            documentType: '',
            sector: '',
            description: '',
            files: []
        }
    }

    onChange = (e) => {
        const state = this.state
        state[e.target.name] = e.target.value;
        this.setState(state);
    }

    handleSelectedFiles = (filesArr) => {
        console.log(filesArr);
        this.setState({files: filesArr}, () => {
            console.log(this.state);
        });
    }

    onSubmit = (e) => {
        e.preventDefault();
        const { companyName, bvdid, documentType, sector, description, files } = this.state;
        const formData = new FormData();
        formData.append("companyName", companyName);
        formData.append("bvdid", bvdid);
        formData.append("documentType", documentType);
        formData.append("sector", sector);
        formData.append("description", description);
        formData.append("files", files);


        axios.post('http://localhost:5000/api/company',formData,
        {
            headers: {
                "Content-type": "multipart/form-data",
            },                    
        } )
          .then((response) => {
            if (response.status >= 200 && response.status < 300) {
                console.log(response.data);
            }
          });

          
      }

    render() {
        const { companyName, bvdid, documentType, sector, description } = this.state;
        return (
            <React.Fragment>

                <div className="bg">
                    <div className="container-fluid">
                        <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <div className="upload-title">UPLOAD FILE</div>
                            <div style={{ display: "flex" }}>
                                <div className="moodys-title">MOODY'S</div>
                            </div>
                        </div>
                    </div>
                    <Dropzone onSelectfiles={this.handleSelectedFiles} />
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-md-12 text-center">
                                <div style={{ display: "flex", justifyContent: 'center' }}>
                                    <div>
                                        <input type="text" placeholder="Insert URL here" style={{ width: '300px', height: '50px', }}/>
                                        {/* <div>
                                            <small><b>Insert URL here</b></small>
                                        </div> */}
                                    </div>
                                    <div style={{ marginLeft: '10px'  }}>
                                        <button type="button" style={{ height: '50px' }} className="btn btn-primary form-control">SEARCH</button>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <Formik
                        enableReinitialize
                        initialValues={{ }} >
                        {({ touched, errors }) => */}
                            <form onSubmit={this.onSubmit}>
                                <div className="main-title up-title">DOCUMENT DETAILS</div>

                                <div className="container-fluid">
                                    <div className="form-group col-md-8">
                                        <div className="row">
                                            <div className="col-md-2">
                                                <label>Company Name</label>
                                            </div>
                                            <div class="col-md-10">
                                                <input type="text" placeholder="Company Name" name="companyName" value={companyName} onChange={this.onChange} style={{ width: "100%", height: "50px" }}/>
                                            </div>
                                        </div>
                                        <br />

                                        <div className="form-group row">
                                            <div className="col-md-2">
                                                <label htmlFor="companyName">BVD9_ID</label>
                                            </div>
                                            <div className="col-md-10">
                                                <select name="bvdid" value={bvdid} onChange={this.onChange} id="bvdid" style={{ width: "100%", height: "50px" }} >
                                                <option value="1">AU004201307</option>
                                                    <option value="2">BE0404021727</option>
                                                    <option value="3">BE0202239951</option>
                                                    <option value="4">BE0214596464</option>
                                                    <option value="5">CHCHE102210767</option>
                                                    <option value="6">MXCCF9305145C9</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="form-group row">
                                            <div className="col-md-2">
                                                <label htmlFor="companyName"
                                                >Type Of Document</label>
                                            </div>
                                            <div className="col-md-10">
                                                &nbsp;
                                                <select name="documentType" value={documentType} onChange={this.onChange} id="bvdid" style={{ width: "100%", height: "50px" }}>
                                                <option value="1">JPG</option>
                                                    <option value="2">PDF</option>
                                                    <option value="3">PNG</option>
                                                </select>
                                            </div>
                                        </div>
                                        <br/>
                                        <div className="form-group row">
                                            <div className="col-md-2">
                                                <label htmlFor="sector"
                                                >Sector</label>
                                            </div>
                                            <div className="col-md-10">
                                                &nbsp;
                                                <select name="sector" value={sector} onChange={this.onChange} id="bvdid" style={{ width: "100%", height: "50px" }}>
                                                <option value="1">Automobiles</option>
                                                    <option value="2">Beverage</option>
                                                    <option value="3">Electric & Gas Utilities</option>
                                                    <option value="4">Chemicals</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="form-group col-md-4">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label htmlFor="description">Description</label>
                                                </div>
                                            </div>
                                            <div class="row">
                                            <div class="col-md-12">
                                                <textarea placeholder="Description" size="5000" type="text" name="description" value={description} onChange={this.onChange} id="bvdid" class="form-control" wrap="soft" style={{ width: "100%", height: "367px", resize: "none", padding: "10px", }}></textarea>
                                            </div>
            
                                            </div>
                                            <div className="row">
                                                <div class="col-md-12">
                                                    <div class="" style={{ display: "flex", justifyContent: "space-between" }}>
                                                        <div>
                                                            <button type="submit" name="submit" className="btn btn-primary up-btn float-right form-control" data-toggle="modal">Submit</button>
                                                        </div>
                                                        <div>
                                                            <button type="submit" name="submit" className="btn btn-primary up-btn float-right form-control" data-toggle="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                     
                                </div>
                            </form>
                    {/* </Formik> */}


                </div>
            </React.Fragment>
        )
    }

}
export default UplaodFile;