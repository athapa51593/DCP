import React, { useState } from "react";

import Dropzone, { useDropzone} from "react-dropzone";
import DropImg from "../../assets/images/dropImage.png"

export default function DropZone(props) {
  const [fileNames, setFileNames] = useState([]);

  const handleDrop = (acceptedFiles) => {
    setFileNames(acceptedFiles.map(file => file.name));
    props.onSelectfiles(acceptedFiles);
  }

  const {
    getRootProps,
    getInputProps,
  } = useDropzone({
    accept: '.pdf'
  });

  return (
    <div className="">
      <Dropzone onDrop={handleDrop} maxFiles={1}>
        {({ getRootProps, getInputProps }) => (
          <div {...getRootProps({ className: "dropzone" })}>
            <input {...getInputProps()} accept="application/pdf"/>
            <img src={DropImg} style={{ width: "250px" }}></img>
            <br/>
            <div style={{ color: "#fff", marginTop: "10px" }}>Drop file here for browse</div>
          </div>
        )}
      </Dropzone>
      <div>
        <ul>
          {fileNames.map(fileName => (
            <li key={fileName}>{fileName}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}