import React, { Component } from "react";
import './style.css';

export default class PopUp extends Component {
  handleClick = () => {
    this.props.toggle();
  };

  render() {
    return (
      <div className="custom-modal">
        <div className="custom-modal-content">
          <span className="close" onClick={this.handleClick}>
            &times;
          </span>
          <h3>Filters!</h3>
        </div>
      </div>
    );
  }
}
