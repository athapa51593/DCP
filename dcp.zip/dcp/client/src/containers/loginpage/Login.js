import React, { useState, useEffect } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "./Login.css";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function validateForm() {
    return email.length > 0 && password.length > 0;
  }

  function handleSubmit(event) {
    event.preventDefault();
    if(email === 'nima@moodys.com' && password === 'nima123'){
      window.location.href="http://localhost:3000/uploadfile"
      console.log('login succesfull!!')
      
    }else{
      console.log("invalid user!!")
    }
  }

  const onLoginHandler = () => {
    if(email === 'nima@moodys.com' && password === 'bishunk123'){
      console.log('login succesfull')
    }
  }

  useEffect(() => {
    document.body.style.backgroundImage = 'linear-gradient(skyblue,white)';
    document.body.style.backgroundRepeat = 'no-repeat'
    document.body.style.backgroundSize = 'cover'
  })

  return (
    <React.Fragment>
      <div id='outer'>
      <h1 style={{marginLeft: '75%', fontWeight: 'bold', color: "white"}}><b>Moody's</b> </h1>
      <br/><br/>
        <h1 style={{marginLeft: '5%', fontWeight: 'bold'}}>Login Page </h1>
        <div className="Login">
          <Form style={{padding: '0px', margin:'auto'}}onSubmit={handleSubmit}>
            <Form.Group size="lg" controlId="email">
              <Form.Label>UserName</Form.Label>
              <Form.Control
                autoFocus
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </Form.Group>
            <Form.Group size="lg" controlId="password">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </Form.Group>
            <Button style={{width: "200px"}} block size="lg" type="submit"  disabled={!validateForm()}>
              Login
            </Button>
          </Form>
        </div>
      </div>
    </React.Fragment>
  );
}