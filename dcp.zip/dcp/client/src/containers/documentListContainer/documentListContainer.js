import React, { Component } from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

import DocumentList from "../../components/documentListComponent/documentList";


const mapStateToProps = (state) => ({



});

const mapDispatchToProps = (dispatch) =>
  bindActionCreators(
    {


    },
    dispatch
  );

const connectFunction = connect(mapStateToProps, mapDispatchToProps);

const DocumentListContainer = connectFunction(
  class DocumentListContainer extends React.Component {

    constructor(props) {
      super(props);
      this.state = {
       
      }
    }


    render() {
      debugger
      return (
        <React.Fragment>
         
          
            <DocumentList {...this.props} />
         
          
        </React.Fragment>
      );

    }
  }
);

export default DocumentListContainer;