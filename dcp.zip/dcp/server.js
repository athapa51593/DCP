var express = require('express');
const fs = require('fs');
  const cors = require('cors');
  var bodyParser = require('body-parser');
var app = express()
var multer = require('multer');
var upload = multer();

const uploadFiles = require("./upload");

const multerS3 = require('multer-s3');
const AWS = require('aws-sdk');

const s3 = new AWS.S3({
  accessKeyId: 'access-key-id',
  secretAccessKey: 'secret-access-key'
});

const uploadFile = (file) => {
  // read content from the file
  const fileContent = fs.readFileSync(file);

  // setting up s3 upload parameters
  const params = {
      Bucket: BUCKET_NAME,
      Key: 'test.pdf', // file name you want to save as
      Body: fileContent
  };

  // Uploading files to the bucket
  s3.upload(params, function(err, data) {
      if (err) {
          throw err
      }
      console.log(`File uploaded successfully. ${data.Location}`)
  });
};

// app.use(bodyParser.json());
app.use(cors());

app.use(bodyParser.json()); 

// for parsing application/xwww-
app.use(bodyParser.urlencoded({ extended: true })); 
//form-urlencoded

// for parsing multipart/form-data
app.use(upload.array()); 
app.use(express.static('public'));

app.use(function (req, res, next) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');
    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Access-Control-Allow-Credentials', true);
    // Pass to next layer of middleware
    next();
});



app.post('/api/company', function(req, res, next) {
  console.log(req.files);
  console.log(req.body);
  // if (req.body.files.length > 0) {
  //   uploadFile(req.body.files[0]);
  // }
  res.send(JSON.stringify({msg: 'File is uploaded successfully'}));
})

app.listen(5000, function(){
  console.log('Express server listening on port 5000')
})